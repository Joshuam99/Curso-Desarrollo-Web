document.addEventListener("DOMContentLoaded", () => {
  // Botón de "Sitio Web"
  const btnSitio = document.querySelector("#btnSitioWeb");

  // Botón de "Aplicación Web"
  const btnApp = document.querySelector("#btnAppWeb");

  // Redirecciones
  btnSitio.addEventListener("click", () => {
    window.location.href = "sitioweb.html";
  });

  btnApp.addEventListener("click", () => {
    window.location.href = "aplicacionweb.html";
  });
});
